
# Personal Website — GitHub Pages Starter

This repo contains a simple, single-file academic website for **Kemal Önder Çetin**, inspired by clean faculty pages (HOME, PEOPLE, RESEARCH, PUBLICATIONS, CODE & DATA, ADVICE, TEACHING, OPPORTUNITIES).

## Quick Deploy (GitHub Pages)
1. Create a new public repository named: `ondercetin.github.io`
2. Add these files to the repo (drag-and-drop via GitHub web UI or push with Git).
3. Go to **Settings → Pages** and ensure the site is served from the `main` branch (`/root`).   Your site will be available at: https://ondercetin.github.io
4. Replace placeholders:
   - `assets/headshot-placeholder.jpg` → your headshot
   - Email, Google Scholar, ORCID, LinkedIn links in `index.html`
   - News, People, Publications sections

## Custom Domain (optional)
If you own a domain like `ondercetin.com`:
1. In your DNS manager, create 4 **A records** pointing to GitHub Pages (these IPs may change; check GitHub docs):
   - `@` → 185.199.108.153
   - `@` → 185.199.109.153
   - `@` → 185.199.110.153
   - `@` → 185.199.111.153
2. (Optional) Create a **CNAME record**:
   - `www` → `ondercetin.github.io`
3. In the GitHub repo, create a file named `CNAME` (no extension) with a single line: `ondercetin.com` (or `www.ondercetin.com`)
4. Revisit **Settings → Pages** and enable **Enforce HTTPS**.

## Local Edits
Just edit `index.html` (it’s a single page). For a multi-page structure later, duplicate sections into separate HTML files and update links.

## No Jekyll
This repo includes a `.nojekyll` file so GitHub Pages serves everything as-is.

## License
You may adapt and reuse this layout freely.
